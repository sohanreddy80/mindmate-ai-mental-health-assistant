<?php

$host = "sql108.infinityfree.com";
$user = "if0_41371686";
$pass = "SOHAN5252";
$db   = "if0_41371686_mindmate_db";

$conn = mysqli_connect($host,$user,$pass,$db);

if($conn){
echo "Database connected successfully";
}else{
echo "Connection failed";
}

?>